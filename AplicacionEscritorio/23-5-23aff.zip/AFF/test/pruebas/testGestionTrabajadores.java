package pruebas;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
import Modelo.Trabajadores;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import controlador.ConsultasTrabajadores;

/**
 * Clase de pruebas para la gestión de trabajadores.
 * 
 * Esta clase contiene pruebas unitarias para diferentes funciones de gestión de trabajadores, como
 * modificación, ingreso, borrado, búsqueda, carga de datos y obtención de código disponible.
 * 
 * Autor: Cristoffer
 */
public class testGestionTrabajadores {
    ConsultasTrabajadores consultas = new ConsultasTrabajadores();   
    
    public testGestionTrabajadores() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }
    
    
    /**
     * Prueba de modificación de trabajador correcta.
     * 
     * Esta prueba verifica si la modificación de un trabajador se realiza correctamente mediante el método
     * actualizarDatosdeTrabajador(). Se espera que el resultado de la modificación sea verdadero (true).
     */
    @Test
    public void testModificarTrabajador() {
        boolean respuesta_esperada = true;
        boolean resultado = consultas.actualizarDatosdeTrabajador(4510, "MARY", "MUÑOZ", 123586934, 1, true, 4, "12345678M");
        assertEquals(respuesta_esperada, resultado);
    }
     
    /**
     * Prueba de ingreso de trabajador.
     * 
     * Esta prueba verifica si el ingreso de un trabajador se realiza correctamente mediante el método
     * IngresarTrabajador(). Se espera que el resultado del ingreso sea verdadero (true).
     */
    @Test
    public void testIngresarTrabajador() {       
        boolean respuesta_esperada = true;   
        boolean resultado = consultas.IngresarTrabajador(4510, "MARY", "MUÑOZ", 123586934, 1, true, 4, "12345678M");
        assertEquals(respuesta_esperada, resultado);
    }
     
    /**
     * Prueba de borrado de trabajador.
     * 
     * Esta prueba verifica si el borrado de un trabajador se realiza correctamente mediante el método
     * BorrarTrabajador(). Se espera que el resultado del borrado sea verdadero (true).
     */
    @Test
    public void testBorrarTrabajador() {
        boolean respuesta_esperada = true;
        boolean resultado = consultas.BorrarTrabajador(4510);
        assertEquals(respuesta_esperada, resultado);
    }
     
    /**
     * Prueba de búsqueda de trabajador.
     * 
     * Esta prueba verifica si la búsqueda de un trabajador se realiza correctamente mediante el método
     * BuscarTrabajador(). Se espera que el resultado de la búsqueda sea verdadero (true).
     */
    @Test
    public void testBuscarTrabajador() {
        boolean respuesta_esperada = true;
        boolean resultado = consultas.BuscarTrabajador("12345678M");
        assertEquals(respuesta_esperada, resultado);
    }
    
    /**
     * Prueba de carga de datos de trabajador.
     * 
     * Esta prueba verifica si la carga de datos de un trabajador se realiza correctamente mediante el método
     * CargarDatos(). Se espera que los datos cargados coincidan con los datos esperados.
     */
    @Test
    public void testCargarDatos() {
        Trabajadores t = new Trabajadores(4510, "MARY", "MUÑOZ");
        Trabajadores resultado = consultas.CargarDatos("12345678M");
        assertEquals(t.getNombre(), resultado.getNombre());
        assertEquals(t.getApellidos(), resultado.getApellidos());
        assertEquals(t.getCod_Trabajador(), resultado.getCod_Trabajador());
    }
    
    /**
     * Prueba de obtención de código disponible.
     * 
     * Esta prueba verifica si la obtención de un código disponible se realiza correctamente mediante el método
     * obtenerCodigoDisponible(). Se espera que el código obtenido coincida con el código esperado.
     */
    @Test
    public void testObtenerCodigoDisponible() {
        int resultadoEsperado = 6;
        int resultado = consultas.obtenerCodigoDisponible();
        assertEquals(resultadoEsperado, resultado);
    }
}