package pruebas;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import controlador.ConsultasMYSQL;

/**
 *
 * @author Cristoffer
 */
public class testAccessoAlSistema {
    
    
    
       @Test
     public void testValidarAccesoAlSistema(){
        String nombre="Cristo";
        int codigo=4;
        //instance=new Cartelera();        
        boolean respuesta_espareada=true;
        ConsultasMYSQL consultas =new ConsultasMYSQL();       
         boolean resultado=consultas.validardatos(nombre, codigo);
         assertEquals(respuesta_espareada, resultado);
     }
    
    

}
