package pruebas;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */

import Modelo.Cuadrillas;
import Modelo.Frutas;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import controlador.ConsultasCuadrillas;


/**
 * Pruebas unitarias para la gestión de cuadrillas.
 * 
 * Esta clase contiene pruebas unitarias para las operaciones de ingreso, borrado y búsqueda de cuadrillas.
 * Cada método de prueba verifica el resultado esperado de una operación en particular y compara el resultado obtenido con el resultado esperado.
 * Se utiliza la clase ConsultasCuadrillas para realizar las operaciones y se verifica que los resultados sean consistentes.
 * 
 * Autor: Cristoffer
 */
public class testGestionFruta {
    ConsultasCuadrillas consultas = new ConsultasCuadrillas(); 
    
    public testGestionFruta() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Prueba de ingreso de una cuadrilla.
     */
    @Test
    public void testIngresarFruta() {    
        boolean respuesta_espareada = true;
        boolean resultado = consultas.InsertarFruta(7, "VE","Uvas");
        assertEquals(respuesta_espareada, resultado);
    }
     
    /**
     * Prueba de borrado de una cuadrilla.
     */
    @Test
    public void testBorrarFruta() {
        boolean respuesta_espareada = true;
        boolean resultado = consultas.borrarFruta(7);
        assertEquals(respuesta_espareada, resultado);
    }
     
    /**
     * Prueba de búsqueda de una cuadrilla.
     */
    @Test
    public void testBuscarFruta() {
        String respuesta_espareada = "7";   
        Frutas f = consultas.buscarFruta(7);
        assertEquals(respuesta_espareada, f.getCodigo());
    }
}
    
    
    
    
