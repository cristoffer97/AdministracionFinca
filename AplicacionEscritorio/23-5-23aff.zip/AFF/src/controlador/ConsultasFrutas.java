/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import Modelo.Cuadrillas;
import Modelo.Frutas;
import Modelo.Trabajadores;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author Cristoffer
 */
public class ConsultasFrutas {
      ConexionBD cbd = new ConexionBD();
      public ConsultasFrutas() {
    }
      
      
      
      //-------------------------------------CRUD FRUTAS------------------------------------
      /*
 Insertar Fruta
 */
 public  boolean InsertarFruta(int codigo,String nombre,String Variedad) {
     boolean resultado=false;
		String sql;
		PreparedStatement ps;
		try {
                    Connection conn = cbd.abrirConexion();
			 //conexion= DriverManager.getConnection ("jdbc:mysql://localhost/aff","root", "");
			// Preparamos la consulta
			 sql = "INSERT INTO `fruta`(`Cod_Fruta`, `Variedad`, `nombre`) VALUES (?,?,?)";
	            ps = conn.prepareStatement(sql);
	            ps.setInt(1,codigo);
	            ps.setString(2,Variedad);
                    ps.setString(3,nombre);
	            
	            ps.executeUpdate();
	            resultado=true;
                    cbd.cerrarConexion();
	        }catch(SQLException e){
	            JOptionPane.showMessageDialog(null, "Error de conexión:" + e.getMessage());
	        }
                return resultado;
	}
 
  /*
 Borrar Cuadrilla
 */
 public boolean borrarFruta(int codtrabaj) {
     boolean resultado=false;
		try {
		PreparedStatement ps;
		String sql = "DELETE FROM fruta WHERE Cod_Fruta="+codtrabaj+";";
				Connection conn = cbd.abrirConexion();

			ps = conn.prepareStatement(sql);		           
		 
		int rowsUpdated = ps.executeUpdate();
		if (rowsUpdated > 0) {
		    resultado=true;
		}
                cbd.cerrarConexion();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
                return resultado;
	}
 
  /**
  * Buscamos la Variedad de fruta
  * @param codigo
  * @return 
  */
    public Frutas buscarFruta(int codigo) {
         Frutas fruta = null;        
        try {
            PreparedStatement ps;
            String sql = "SELECT * FROM fruta f WHERE f.Cod_Fruta="+codigo+";";
            Connection conn = cbd.abrirConexion();
            Statement s = conn.createStatement();
            ResultSet rs = s.executeQuery(sql);

            while (rs.next()) {
                String cod = rs.getString(1);
                String Variedad = rs.getString(2);
                String nombre = rs.getString(3);
               
                fruta=new Frutas(cod, nombre,Variedad);
                
                
    }
        cbd.cerrarConexion();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
  return fruta;       
   
    }

      
      
}
