package controlador;

public interface Configuracion {
	String DBHOST = "localhost";
	String DBNAME = "aff";        
        int tamañoVentana=600;
        
        //Configuracion de las tablas
        int colorfondorojo=51;
        int colorfondoverde=153;
        int colorfondoazul=0;
        //Color de las palabras
        int colorletrarojo=255;
        int colorletraverde=255;
        int colorletraazul=255;
        
        
}
