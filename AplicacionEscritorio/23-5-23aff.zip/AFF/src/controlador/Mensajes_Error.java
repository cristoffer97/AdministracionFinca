/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package controlador;

/**
 *
 * @author Cristoffer
 */
public interface Mensajes_Error {
    //Mensajes e error al fichar un trabajador
    String TituloError="Error";
    String Fichaje_Duplicado="El trabajador ya esta fichado hoy";
    String Codigo_No_Registrado="El codigo introducido no esta registrado";
    String Codigo_No_Valido="Introduzca un codigo Valido";
    //Mensajes de error al acceder al sistema
    String Datos_NO_VALIDOS="Datos incorrectos reviselos";
    

    
    //Mensajes gestion Cuadrillas
     String insertadoIncorrectoCuadrilla= "Revise los datos";
     String insertadoCorrectoCuadrilla= "La cuadrilla se ha insertado de forma correcta";
     
     String borradoIncorrectoCuadrilla= "Error no puede borrar una cuadrilla que tenga trabajadores";
     String borradoCorrectoCuadrilla= "La cuadrilla ha sido borrada";
     
     
     
     
//Mensajes gestion Trabajadores
    String insertadoCorrectoTrabajador="El trabajador se ha guardado";
    String insertadoIncorrectoTrabajador="No se ha podido insertar el registro";
    String modificadoCorrectoTrabajador="Se ha actualizado los datos del trabajador";
    String modificadoIncorrectoTrabajador="No se ha podido actualizar los datos";
    String borradoCorrectoTrabajador="Se ha dado de baja al trabajador";
    String borradoIncorrectoTrabajador="Revisa el Codigo del trabajador";
    String TitulosborradoError="Error al dar de baja";
    String TitulosbuscarError="Error al buscar";
    String datosIncorrectosTrabajador="Revise los datos del empleado";
    String TitulosIngresodatosError="Error al ingresar los datos";
    String TitulosModificardatosError="Error al modificar los datos";
    String MensajeDNIRegistrado="El DNI introducido esta registrado\n ¿Quieres cargar los datos del trabajador?";
    String TituloDNIRegistrado="Aviso";
    //MetodoPOP
    String NingunRegistroSeleccionado="No se ha seleccionado ningún registro para borrar.";
    String MensajeBorradoVariosTrabajadores="¿Está seguro de que desea borrar los registros seleccionados?";
    String MensajeBorradoExitosoVariosTrabajadores="Registros borrados correctamente";
    String MensajeBorradoExitosoTrabajador="Registros borrados correctamente";
}
