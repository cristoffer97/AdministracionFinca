package CrudWebservice;
/**
 * Clase Constantes
 * 
 * @author encarna
 *
 */
public class Constantes {

	public static final String SERVER = "http://localhost/aff/";


	public static final String ACCESOALSISTEMA = SERVER + "AccederAlSistema.php";

	public static final String INSERTAR_INFORMES = SERVER+ "insertarInformes.php";
	
	public static final String MODIFICAR_INFORME = SERVER+ "modificarInformes.php";
	
	public static final String BORRARINFORMES = SERVER+ "BORRARINFORME.php";
        
        public static final String BUSCARINFORME = SERVER+ "BuscarRegistro.php";
	
        public static final String OBTENERTODOS = SERVER+ "ObtenerTodosLosRegistros.php";

}
