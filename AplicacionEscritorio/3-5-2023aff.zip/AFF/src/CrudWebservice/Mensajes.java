/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package vista;

/**
 *
 * @author Cristoffer
 */
public interface Mensajes {
    String Titulo="Gestion de Informes";
    
    String ERRORBUSCAR="Los datos buscado no estan registrados";
    
    String MensajeInsertarpositiva="Informe Guardado";
    String MensajeInsertarnegativa="Informe no Guardado";
    
    String MensajeModificadopositiva="Informe Modificado";
    String MensajeModificadonegativa="Informe no Modificado";
    
    String Mensajeborrarpositiva="Informe Borrado";
    String Mensajeborrarnegativa="Informe no Borrado";
    
    String MensajeLoguenegativa="Los datos introducidos no pertenecen a ningun Perito";
    
    String DatosNOValidos="Datos No Validos reviselos";
}
