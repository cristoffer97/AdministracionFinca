package PruebasVentanas;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import javax.swing.*;
import java.awt.*;

public class prueba extends JFrame {
    private JButton button1, button2, button3, button4, button5, button6;
    private JTable table;

    public prueba() {
        setTitle("Mi Ventana");
        setSize(500, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Creamos los componentes
        button1 = new JButton("Botón 1");
        button2 = new JButton("Botón 2");
        button3 = new JButton("Botón 3");
        button4 = new JButton("Botón 4");
        button5 = new JButton("Botón 5");
        button6 = new JButton("Botón 6");

        String[] columnas = {"Columna 1", "Columna 2", "Columna 3"};
        String[][] datos = {{"Dato 1", "Dato 2", "Dato 3"}, {"Dato 4", "Dato 5", "Dato 6"}};
        table = new JTable(datos, columnas);

        // Creamos los paneles para los componentes
        JPanel panelInferior = new JPanel(new BorderLayout());

        panelInferior.add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel panelBotones = new JPanel(new GridLayout(2, 3));
        panelBotones.add(button1);
        panelBotones.add(button2);
        panelBotones.add(button3);
        panelBotones.add(button4);
        panelBotones.add(button5);
        panelBotones.add(button6);

        panelInferior.add(panelBotones, BorderLayout.SOUTH);

        // Añadimos los paneles a la ventana
        add(panelInferior, BorderLayout.CENTER);

        setVisible(true);
    }

    public static void main(String[] args) {
        new prueba();
    }
}