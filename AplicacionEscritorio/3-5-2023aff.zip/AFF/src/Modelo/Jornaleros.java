/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Cristoffer
 */
public class Jornaleros extends Trabajadores{

    public Jornaleros() {
    }

   public Jornaleros(int Cod_Trabajador, int telefono, String nombre, String apellidos, int Cuadrilla, boolean Podador, String tipoTrabajador,String dni) {
        super(Cod_Trabajador, telefono, nombre, apellidos, Cuadrilla, Podador, tipoTrabajador,dni);
    }

   
    
    
    
    
}
