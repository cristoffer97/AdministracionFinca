/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package controlador;

/**
 *
 * @author Cristoffer
 */
public interface Mensajes_Error {
    //Mensajes e error al fichar un trabajador
    String TituloError="Error";
    String Fichaje_Duplicado="El trabajador ya esta fichado hoy";
    String Codigo_No_Registrado="El codigo introducido no esta registrado";
    String Codigo_No_Valido="Introduzca un codigo Valido";
    //Mensajes de error al acceder al sistema
    String Datos_NO_VALIDOS="Datos incorrectos reviselos";
    
    //Mensajes gestion Tractores
    String insertadoCorrectoTractor="Se han insertado los datos";
    String insertadoIncorrectoTractor="No se ha podido insertar el registro";
    String modificadoCorrectoTractor="Se ha actualizado el tractor";
    String modificadoIncorrectoTractor="No se podido actualizar";
    String borradoCorrectoTractor="Se ha borrado el tractor";
    String borradoIncorrectoTractor="No se ha podido borrar el tractor";
    String datosIncorrectosTractor="Revise los datos";
    
    //Mensajes gestion Cuadrillas
     String insertadoCorrectoCuadrilla= "Se ha registrado los datos";
     String CorrectoCuadrilla= "Se ha registrado los datos";
   
}
