package PruebasVentanas;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

public class VentanaRedimensionable {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(VentanaRedimensionable::crearVentana);
    }

    private static void crearVentana() {
        // Crear la ventana principal
        JFrame ventana = new JFrame("Ventana redimensionable");
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Crear la barra de menú
        JMenuBar menuBar = new JMenuBar();
        JMenu archivoMenu = new JMenu("Archivo");
        JMenuItem salirItem = new JMenuItem("Salir");
        salirItem.addActionListener(e -> System.exit(0));
        archivoMenu.add(salirItem);
        menuBar.add(archivoMenu);
        ventana.setJMenuBar(menuBar);

        // Crear la JTable con datos de ejemplo
        String[] columnas = {"Nombre", "Edad", "Correo"};
        Object[][] datos = {
                {"Juan", 25, "juan@example.com"},
                {"María", 30, "maria@example.com"},
                {"Pedro", 35, "pedro@example.com"}
        };
        DefaultTableModel modeloTabla = new DefaultTableModel(datos, columnas);
        JTable tabla = new JTable(modeloTabla);

        // Crear los botones con atajos de teclado
        JButton agregarButton = new JButton("Agregar");
        agregarButton.setMnemonic(KeyEvent.VK_A);
        agregarButton.addActionListener(e -> agregarFila(tabla, modeloTabla));

        JButton eliminarButton = new JButton("Eliminar");
        eliminarButton.setMnemonic(KeyEvent.VK_E);
        eliminarButton.addActionListener(e -> eliminarFila(tabla, modeloTabla));

        // Crear el panel con los botones
        JPanel panelBotones = new JPanel();
        panelBotones.add(agregarButton);
        panelBotones.add(eliminarButton);

        // Crear el contenedor principal y agregar los componentes
        Container container = ventana.getContentPane();
        container.setLayout(new BorderLayout());
        container.add(new JScrollPane(tabla), BorderLayout.CENTER);
        container.add(panelBotones, BorderLayout.SOUTH);

        // Permitir redimensionar la ventana
        ventana.setResizable(true);

        // Mostrar la ventana
        ventana.setSize(400, 300);
        ventana.setLocationRelativeTo(null);
        ventana.setVisible(true);
    }

    private static void agregarFila(JTable tabla, DefaultTableModel modelo) {
        modelo.addRow(new Object[]{"Nuevo nombre", 0, "nuevo@ejemplo.com"});
    }

    private static void eliminarFila(JTable tabla, DefaultTableModel modelo) {
        int filaSeleccionada = tabla.getSelectedRow();
        if (filaSeleccionada >= 0) {
            modelo.removeRow(filaSeleccionada);
        } else {
            JOptionPane.showMessageDialog(null, "Selecciona una fila para eliminar", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}