/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PruebasVentanas;

/**
 *
 * @author Cristoffer
 */

import javax.swing.*;
import java.awt.*;

public class pruebaf extends JFrame {

    public pruebaf() {
        initComponents();
    }

    private void initComponents() {
        JPanel panelPrincipal = new JPanel();
        JPanel panelBotones = new JPanel();
        JScrollPane panelTabla = new JScrollPane();
        JTable tabla = new JTable();
        JTextField txtCampo1 = new JTextField();
        JTextField txtCampo2 = new JTextField();
        JButton btn1 = new JButton("Botón 1");
        JButton btn2 = new JButton("Botón 2");
        JButton btn3 = new JButton("Botón 3");
        JButton btn4 = new JButton("Botón 4");
        JButton btn5 = new JButton("Botón 5");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Mi Ventana");
        setPreferredSize(new Dimension(600, 400));

        panelPrincipal.setLayout(new GridBagLayout());

        txtCampo1.setPreferredSize(new Dimension(150, 25));
        txtCampo2.setPreferredSize(new Dimension(150, 25));

        panelBotones.setLayout(new GridLayout(5, 1));
        panelBotones.add(btn1);
        panelBotones.add(btn2);
        panelBotones.add(btn3);
        panelBotones.add(btn4);
        panelBotones.add(btn5);

        panelTabla.setViewportView(tabla);

        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 0;
        c.fill = GridBagConstraints.BOTH;
        c.weightx = 0.3;
        c.weighty = 1;
        panelPrincipal.add(panelBotones, c);

        c.gridx = 1;
        c.gridy = 0;
        c.fill = GridBagConstraints.BOTH;
        c.weightx = 0.7;
        c.weighty = 1;
        panelPrincipal.add(panelTabla, c);

        c.gridx = 0;
        c.gridy = 1;
        c.fill = GridBagConstraints.NONE;
        c.weightx = 0.0;
        c.weighty = 0.0;
        panelPrincipal.add(txtCampo1, c);

        c.gridx = 1;
        c.gridy = 1;
        c.fill = GridBagConstraints.NONE;
        c.weightx = 0.0;
        c.weighty = 0.0;
        panelPrincipal.add(txtCampo2, c);

        getContentPane().add(panelPrincipal);
        pack();
    }

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new pruebaf().setVisible(true);
            }
        });
    }
}
    


