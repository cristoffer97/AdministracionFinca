/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.Arrays;
import javax.swing.SwingWorker;

public class ExportDBWorker extends SwingWorker<Void, Void> {
    private final String dbName;
    private final String dbUser;
    private final String dbPassword;
    private final String exportPath;

    public ExportDBWorker(String dbName, String dbUser, String dbPassword, String exportPath) throws IOException {
        this.dbName = dbName;
        this.dbUser = dbUser;
        this.dbPassword = dbPassword;
        this.exportPath = exportPath;
    }
    
    @Override
    protected Void doInBackground() throws Exception {
        //String[] command = {"cmd.exe", "cd C:\\xampp\\mysql\\bin", "mysqldump", "-u", dbUser, "-p" + dbPassword, dbName+" > "+exportPath};
          //String[] command = {"cmd.exe", "/c", "mysqldump", "-u", dbUser, "-p" + dbPassword, dbName+" "+exportPath};
      String[] command = {"cmd.exe", "/c", "cd", "C:\\xampp\\mysql\\bin", "&&", "mysqldump", "-u", dbUser, "-p" + dbPassword, dbName, ">", exportPath};


          ProcessBuilder pb = new ProcessBuilder(command);
          pb.redirectErrorStream(true);

        Process process = pb.start();
        try (Writer writer = new OutputStreamWriter(new FileOutputStream(new File(exportPath)))) {
            byte[] buffer = new byte[1024];
            int length;
            while ((length = process.getInputStream().read(buffer)) != -1) {
                writer.write(new String(Arrays.copyOf(buffer, length)));
            }
        } catch (IOException ex) {
            throw new RuntimeException("Error al escribir el archivo de exportación: " + ex.getMessage(), ex);
        }

        int exitCode = process.waitFor();
        if (exitCode != 0) {
            throw new RuntimeException("Error al exportar la base de datos: Código de salida " + exitCode);
        }

        return null;
    }

    @Override
    protected void done() {
        try {
            get();
            System.out.println("Exportación completada con éxito");
        } catch (Exception ex) {
            System.out.println("Error al exportar la base de datos: " + ex.getMessage());
        }
    }
}