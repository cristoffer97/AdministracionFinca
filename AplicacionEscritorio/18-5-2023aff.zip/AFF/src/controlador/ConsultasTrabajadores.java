/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import Modelo.Cuadrillas;
import Modelo.Tarea;
import Modelo.Trabajadores;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLSyntaxErrorException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Cristoffer
 */
public class ConsultasTrabajadores {
     ConexionBD cbd = new ConexionBD();
      public ConsultasTrabajadores() {
    }
//-----------------------------------CRUD SOBRE LA TABLA DE TRABAJADORES
 /*
 Actualizamos los datos del trabajador en nuestra base de datos
 */ 
 public boolean actualizarDatosdeTrabajador(int codtrabaj, String nombre, String apellido, int telefono, int cuadrilla, boolean podador, int tipotrabajador,String dni) {
        boolean resultado=false;
        try {
		PreparedStatement ps;
		//String sql = "UPDATE trabajadores SET nombre=?, apellido=?, telefono=?, Cuadrilla=?,Podador=?, Tipo=? WHERE Cod_Trabajador="+codtrabaj+";";
		String sql="UPDATE trabajadores SET nombre=?, apellido=?, DNI=?, telefono=?, Cuadrilla=?, podador=?, Tipo=? WHERE Cod_Trabajador="+codtrabaj+";";
		 
		//PreparedStatement statement = conn.prepareStatement(sql);
		Connection conn = cbd.abrirConexion();
			ps = conn.prepareStatement(sql);
		
             ps.setString(1,nombre);
             ps.setString(2, apellido);
             ps.setString(3, dni);
             ps.setInt(4, telefono);
             ps.setInt(5, cuadrilla);
             ps.setBoolean(6, podador);
             ps.setInt(7, tipotrabajador);
             
            
		 
		int rowsUpdated = ps.executeUpdate();
		if (rowsUpdated > 0) {
		    resultado=true;
		}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        return resultado;
    }
 
  public void actualizarCuadrillaVariosTrabajadores(int codtrabaj, int cuadrilla) {
        boolean resultado=false;
        try {
		PreparedStatement ps;
		
		String sql="UPDATE trabajadores SET Cuadrilla=? WHERE Cod_Trabajador="+codtrabaj+";";
		 
		//PreparedStatement statement = conn.prepareStatement(sql);
		Connection conn = cbd.abrirConexion();
			ps = conn.prepareStatement(sql);
		
             ps.setInt(1, cuadrilla);

		int rowsUpdated = ps.executeUpdate();
		if (rowsUpdated > 0) {
		    resultado=true;
		}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
    }
/**
 * Actualizamos los valores recibidos del modificar
 * @param codtrabaj
 * @param cuadrilla
 * @param tipotrabajador
 * @param podador
 * @return 
 */
 public boolean actualizarTrabajador(int codtrabaj, int cuadrilla, int tipotrabajador,boolean podador) {
        boolean resultado=false;
        try {
		PreparedStatement ps;
		//String sql = "UPDATE trabajadores SET nombre=?, apellido=?, telefono=?, Cuadrilla=?,Podador=?, Tipo=? WHERE Cod_Trabajador="+codtrabaj+";";
		String sql="UPDATE trabajadores SET Cuadrilla=?, podador=?, Tipo=? WHERE Cod_Trabajador="+codtrabaj+";";
		 
		//PreparedStatement statement = conn.prepareStatement(sql);
		Connection conn = cbd.abrirConexion();
			ps = conn.prepareStatement(sql);

             ps.setInt(1, cuadrilla);
             ps.setBoolean(2, podador);
             ps.setInt(3, tipotrabajador);
             
            
		 
		int rowsUpdated = ps.executeUpdate();
		if (rowsUpdated > 0) {
		    resultado=true;
		}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        return resultado;
    }

/*
    Metodo que borra el trabajador de la Base De Datos
    */
 public boolean BorrarTrabajador(int codtrabaj) {
     boolean resultado=false;
		try {
		PreparedStatement ps;
		String sql = "DELETE FROM trabajadores WHERE Cod_Trabajador="+codtrabaj+";";		
		Connection conn = cbd.abrirConexion();

                ps = conn.prepareStatement(sql);		     	 
		int rowsUpdated = ps.executeUpdate();
		if (rowsUpdated > 0) {
		    resultado=true;
		}
                cbd.cerrarConexion();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
                
                return resultado;
                
	}
 

 
/*
    Metodo que ingresa el trabajador en la Base De Datos
    */

 public boolean IngresarTrabajador(int codtrabaj,String nombre,String apellido,int telefono,int cuadrilla,boolean podador,int tipo,String dni){
     boolean resultado=false;
     String sql;
		PreparedStatement ps;
		try {
                    ConexionBD cbd = new ConexionBD();
                    Connection conn = cbd.abrirConexion();
			 
			// Preparamos la consulta
			 sql = "INSERT INTO trabajadores(Cod_Trabajador, nombre, apellido, telefono, Cuadrilla, podador, Tipo, DNI) VALUES (?,?,?,?,?,?,?,?)";
	            ps = conn.prepareStatement(sql);
	            ps.setInt(1,codtrabaj);
	            ps.setString(2,nombre );
	            ps.setString(3,apellido );
	            ps.setInt(4,telefono);
	            ps.setInt(5,cuadrilla );
                    ps.setBoolean(6, podador); 
                    ps.setInt(7, tipo);
                    ps.setString(8, dni);
	            

	            ps.executeUpdate();
	            resultado=true;
	        }catch(SQLException e){
	            JOptionPane.showMessageDialog(null, "Error de conexión:" + e.getMessage());
	        }
                return resultado;
 }

 
/**
  * Metodo que comprueba que el codigo del trabajador es valido
  * @param codtrabaj
  * @return 
  */
    
    public boolean comprobarCodigoValido(int codtrabaj) {
        boolean resultado=false;
		try {
		PreparedStatement ps;
		String sql = "SELECT * FROM trabajadores WHERE Cod_Trabajador="+codtrabaj+";";		
		Connection conn = cbd.abrirConexion();

                ps = conn.prepareStatement(sql);		     	 
		int rowsUpdated = ps.executeUpdate();
		if (rowsUpdated < 0) {
		    resultado=true;
		}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
                
                return resultado;
	}

    public boolean BuscarTrabajador(String DNIBUSCADO) {
             
                    boolean valido = false;   
try {                      
        String consulta="SELECT * FROM registrotrabajadores WHERE DNI='"+DNIBUSCADO+"';";
        Connection conn = cbd.abrirConexion();
                	 //conexion= DriverManager.getConnection ("jdbc:mysql://localhost/aff","root", "");
                         // Preparamos la consulta
			Statement s = conn.createStatement();
                         
                        ResultSet rs=s.executeQuery(consulta);
                                        
                        int cantidad=0;            
                        while(rs.next()){
                            cantidad++;
                        }                        
                        if(cantidad>0){
                            valido=true;                               
                          }                                                                      
                        
    }catch(SQLSyntaxErrorException e){
        
       } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


return valido;
    }

    public Trabajadores CargarDatos(String DNIBUSCADO) {
     Trabajadores t=null;
    try {
                Connection conn = cbd.abrirConexion();
                    String sql="SELECT rt.Cod_Trabajador,rt.Nombre,rt.Apellidos\n" +
                                "FROM registrotrabajadores rt\n" +
                                    "WHERE DNI='"+DNIBUSCADO+"'";                    
                    
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery (sql);
			// Recorremos el resultado, mientras haya registros para leer, y escribimos el resultado en pantalla.
			while (rs.next()){   
                            int Codigo=rs.getInt(1);
                            String Nombre= rs.getString(2);
                            String Apellidos= rs.getString(3);
                            t=new Trabajadores(Codigo,Nombre,Apellidos);        
                            
			}
                        
                        cbd.cerrarConexion();
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    
    return t;
    }
    }
    
    
      

